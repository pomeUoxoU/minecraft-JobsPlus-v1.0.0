/* v4.2a – smartphone menu + virtual shop + seller mail */
import { world, system, Player, ItemStack } from "@minecraft/server";
import { ActionFormData as A, MessageFormData as M, ModalFormData as O } from "@minecraft/server-ui";

/*** 設定 **************************************************************/
const MONEY = "money#";
const SHOP  = "shop_list";
const MAIL  = "mail#";
const LV_MAX   = 10;
const XP_STEP  = 100;
const PAY_RATE = [1.00,1.05,1.10,1.15,1.20,1.25,1.30,1.35,1.40,1.50];
const XP_KEY   = "xp#";
const PHONE_ID   = "minecraft:paper";
const PHONE_NAME = "スマホ";
const FEE = 100;
const KIT_ID    = "minecraft:paper";
const KIT_NAME  = "回復キット";
const KIT_PRICE = 50;
const PRESET = [1000, 5000, 10000, 50000];
/************************************************************************/

/* 職業定義 */
const JOBS = {
  logger:   { t:"job:logger",   n:"木こり" , p:5,  c:i=>i.endsWith("_log")||i.endsWith("_wood") },
  miner:    { t:"job:miner",    n:"炭鉱夫"  , p:4,  c:i=>i.endsWith("_ore")||i.includes("stone") },
  fencer:   { t:"job:fencer",   n:"ハンター" , p:3 },
  fisher   : { t:"job:fisher"   , n:"漁師"    , p:4  }, 
  digger   : { t:"job:digger"   , n:"整地師"  , p:2  , c:i=>i==="minecraft:dirt"||i==="minecraft:grass"} ,
  farmer   : { t:"job:farmer"   , n:"農家"    , p:3  },
  paramedic:{ t:"job:paramedic",n:"救命士"  , p:20 }
};


/* ── ユーティリティ ── */
const raw = t => ({ rawtext:[{text:t}] });
const gm  = p => +world.getDynamicProperty(MONEY+p.id) || 0;
const sm  = (p,v)=>world.setDynamicProperty(MONEY+p.id, String(v));
const am = (p, base, label) => {
  const level = lv(p);                       // 現在 Lv
  const rate  = PAY_RATE[level - 1];         // テーブルから倍率取得
  const pay   = Math.round(base * rate);

  sm(p, gm(p) + pay);                        // 所持金加算
  p.onScreenDisplay?.setActionBar(`+${pay}$ (${label} Lv${level})`);
};

const sL = ()=>JSON.parse(world.getDynamicProperty(SHOP) || "[]");
const sS = l =>world.setDynamicProperty(SHOP, JSON.stringify(l));
const mL = id=>JSON.parse(world.getDynamicProperty(MAIL+id) || "[]");
const mS = (id,l)=>world.setDynamicProperty(MAIL+id, JSON.stringify(l));

function gx(p){  return +world.getDynamicProperty(XP_KEY+p.id)||0;  }
function sx(p,v){world.setDynamicProperty(XP_KEY+p.id,String(v));   }
function lv(p){  return Math.min(Math.floor(gx(p)/XP_STEP)+1,LV_MAX);}
function addXP(p,add){
  let xp = gx(p) + add;
  const before = lv(p);
  sx(p,xp);
  const after  = lv(p);
  if(after>before){
    p.sendMessage(raw(`§b[LvUp] ${before} → ${after}`));
  }
}

/* スマホ配布─ */
world.afterEvents.playerSpawn.subscribe(e => {
  const p = e.player;

  if (!p.hasTag("has_phone")) {
    system.run(() => {
      const inv = p.getComponent("inventory").container;
      const phone = new ItemStack(PHONE_ID, 1);
      phone.nameTag = PHONE_NAME;
      inv.addItem(phone);
     /* 初回参加メッセージ */
     p.sendMessage({
       rawtext:[
         {text:"§a-- このワールドには Jobs plus v1.0.0 が導入されています --\n"},
         {text:"・チャット欄に §e/function menu§r と入力するとメニューが開きます\n"},
         {text:"・定価 100 円の §eスマホ§r をぜひご活用ください\n"},
         {text:"§a-- Have a nice day! --"}
       ]
     });
      
      p.addTag("has_phone");                 // 二度配らない
    });
  }

  /* 売却通知 */
  const mail = mL(p.id);
  if (mail.length) {
    mail.forEach(m => p.sendMessage(raw(`§b[売却通知] ${m}`)));
    mS(p.id, []);
  }
});


/* スマホでメニュー */
const itemUseEvent =
      (world.beforeEvents && world.beforeEvents.itemUse) ||
      (world.afterEvents  && world.afterEvents.itemUse)  ||
      (world.events       && world.events.itemUse);

itemUseEvent.subscribe(e=>{
  const p = e.source;
  if (p instanceof Player &&
      e.itemStack && e.itemStack.typeId === PHONE_ID &&
      e.itemStack.nameTag === PHONE_NAME) {
    system.run(() => openRoot(p));
  }
});


/* /function menu */
const scriptEv =
      (system.afterEvents && system.afterEvents.scriptEventReceive) ||
      (world.events       && world.events.scriptEvent);

scriptEv.subscribe(ev => {
  if (ev.id !== "je:open_menu") return;
  const p =
        ev.initiator     ??
        ev.sourceEntity  ??
        ev.player        ??
        null;

  if (p) {
    system.run(() => openRoot(p));
  } else {
    world.sendMessage({rawtext:[{text:"§c[DEBUG] プレイヤーを取得できません"}]});
  }
});


/* GUI */
function openRoot(p){
  new A().title("Main Menu")
    .button("職業").button("銀行").button("ショップ")
    .show(p).then(r=>{
      if(r.canceled) return;
      [jobMenu,bankMenu,shopMenu][r.selection](p);
    });
}

/* 職業 */
function jobMenu(p){
  new A().title("職業").button("就職").button("退職").show(p).then(r=>{
    if(r.canceled) return;
    r.selection ? retire(p) : chooseJob(p);
  });
}
function chooseJob(p){
  const keys=Object.keys(JOBS),f=new A().title("就職先");
  keys.forEach(k=>f.button(JOBS[k].n));
  f.show(p).then(r=>{
    if(!r.canceled) setJob(p,keys[r.selection]);
  });
}
function setJob(p,k){
  Object.values(JOBS).forEach(v=>p.removeTag(v.t));
  p.addTag(JOBS[k].t);
  p.sendMessage(raw(`§e${JOBS[k].n} に就職しました`));
}
function retire(p){
  Object.values(JOBS).forEach(v=>p.removeTag(v.t));
  sx(p, 0);           // XP 0
  p.sendMessage(raw("§e退職しました"));
}

/* 銀行 */
function bankMenu(p){
  new A().title("銀行").button("残高照会").button("送金").show(p).then(r=>{
    if(r.canceled) return;
    r.selection ? chooseRecipient(p) : showBal(p);
  });
}
function showBal(p){
  new M().title("残高").body(`残高: ${gm(p)} $`).button1("OK").show(p);
}
function chooseRecipient(p){
  const list=world.getPlayers().filter(x=>x!==p);
  if(!list.length){p.sendMessage(raw("§c相手がいません"));return;}
  const f=new A().title("送金相手"); list.forEach(pl=>f.button(pl.nameTag));
  f.show(p).then(r=>{
    if(!r.canceled) chooseAmount(p,list[r.selection]);
  });
}
function chooseAmount(f,t){
  const form=new A().title(`送金額 - ${t.nameTag}`);
  PRESET.forEach(a=>form.button(`${a}$`));
  form.button("その他入力…");
  form.show(f).then(r=>{
    if(r.canceled) return;
    r.selection<PRESET.length ? doPay(f,t,PRESET[r.selection]) : customPay(f,t);
  });
}
const customPay=(f,t)=>new O().title("金額入力").textField("額","").show(f).then(r=>{
  if(r.canceled) return;
  const a=+r.formValues[0];
  if(a>0) doPay(f,t,a);
});
function doPay(f,t,a){
  if(gm(f)<a+FEE){f.sendMessage(raw("§c残高不足"));return;}
  sm(f,gm(f)-a-FEE); sm(t,gm(t)+a);
  f.sendMessage(raw("§a送金完了")); t.sendMessage(raw(`§a${f.nameTag} から ${a}$ 受取`));
}

/* --- ショップ --- */
function shopMenu(p){
  new A().title("ショップ").button("出品").button("購入").show(p).then(r=>{
    if(r.canceled) return;
    r.selection ? buyList(p) : sell(p);
  });
}
/* 出品 */
function sell(p){
  const inv=p.getComponent("inventory").container, slot=p.selectedSlot||0, it=inv.getItem(slot);
  if(!it){p.sendMessage(raw("§c手に持ったアイテムがありません"));return;}
  new O().title("価格入力").textField("price","").show(p).then(r=>{
    if(r.canceled) return;
    const price=+r.formValues[0];
    if(price<=0) return;
    inv.setItem(slot,null);
    const list=sL();
    list.push({id:it.typeId,amount:it.amount,price,seller:p.nameTag,sellerId:p.id});
    sS(list);
    p.sendMessage(raw("§a出品しました！"));
  });
}
/* 購入 */
function buyList(p){
  ensurePhoneListing();
  ensureKitListing();
  const list=sL(); if(!list.length){p.sendMessage(raw("§e出品がありません"));return;}
  const f=new A().title("商品一覧");
  list.forEach(e=>f.button(`${e.id} x${e.amount} - ${e.price}$ (${e.seller})`));
  f.show(p).then(r=>{
    if(!r.canceled) confirmBuy(p,r.selection,list);
  });
}
function confirmBuy(p,i,list){
  if(i<0||i>=list.length) return;
  const e=list[i];
  new M().title("購入確認").body(`${e.id} x${e.amount}\n${e.price}$`).button1("購入").button2("戻る").show(p).then(r=>{
    if(r.canceled||r.selection) return;
    if(gm(p)<e.price){p.sendMessage(raw("§c残高不足"));return;}
    /* 決済 */
    sm(p,gm(p)-e.price);
    const stack = new ItemStack(e.id, e.amount);
    if (e.nameTag) stack.nameTag = e.nameTag;
    p.getComponent("inventory").container.addItem(stack);
    const sMoney=(+world.getDynamicProperty(MONEY+e.sellerId)||0)+e.price;
    world.setDynamicProperty(MONEY+e.sellerId,String(sMoney));
    const note=`${e.id} x${e.amount} が ${p.nameTag} に売れました (+${e.price}$)`;
    const online=world.getPlayers().find(pl=>pl.id===e.sellerId);
    online ? online.sendMessage(raw(`§b[売却通知] ${note}`))
           : mS(e.sellerId,[...mL(e.sellerId),note]);
    list.splice(i,1); sS(list);
    p.sendMessage(raw("§a購入完了！"));
  });
}

/* スマホ常設（価格 100 $） */
function ensurePhoneListing(){
  const list = sL();
  const exists = list.some(e =>
      e.id === PHONE_ID &&
      e.nameTag === PHONE_NAME &&
      e.price === 100);

  if (!exists){
    list.push({
      id: PHONE_ID,
      amount: 1,
      price: 100,
      nameTag: PHONE_NAME,
      seller: "System",
      sellerId: "system"
    });
    sS(list);
  }
}


/* 回復キット常設（価格 50 $） */
function ensureKitListing(){
  const list = sL();
  const exists = list.some(e =>
      e.id === KIT_ID &&
      e.nameTag === KIT_NAME &&
      e.price === KIT_PRICE);

  if (!exists){
    list.push({
      id: KIT_ID,
      amount: 1,
      price: KIT_PRICE,
      nameTag: KIT_NAME,
      seller: "System",
      sellerId: "system"
    });
    sS(list);
  }
}


/* 職業収入イベント ─ ブロック破壊 */
world.afterEvents.playerBreakBlock.subscribe(ev=>{
  const id = ev.breakBlockPermutation
               ? ev.breakBlockPermutation.type.id
               : ev.brokenBlockPermutation.type.id,
        p  = ev.player;

  if (p.hasTag(JOBS.logger.t) && JOBS.logger.c(id)){
      am(p, JOBS.logger.p, JOBS.logger.n);
      addXP(p, 5);               // 木こり
  }
  else if (p.hasTag(JOBS.miner.t) && JOBS.miner.c(id)){
      am(p, JOBS.miner.p, JOBS.miner.n);
      addXP(p, 4);               // 炭鉱夫
  }
  else if (p.hasTag(JOBS.digger.t) && JOBS.digger.c(id)){      
      am(p, JOBS.digger.p, JOBS.digger.n);  
      addXP(p,3);                // 整地師
  }
});

/* 職業収入イベント ─ Mob 討伐 */
world.afterEvents.entityDie.subscribe(ev=>{
  const src    = ev.damageSource;
  const killer = src ? src.damagingEntity : undefined;

  if (killer instanceof Player && killer.hasTag(JOBS.fencer.t)){
      am(killer, JOBS.fencer.p, JOBS.fencer.n);
      addXP(killer, 6);          // ハンター XP +6 ★
  }
});

/* 職業収入イベント ─ 釣り */
const fishEvt =
      (world.afterEvents && world.afterEvents.entityItemPickup) ||   // Win/Android
      (world.events       && world.events.entityPickUpItem);         // Switch 等旧API

fishEvt?.subscribe(ev=>{
    const p = ev.player ?? ev.entity;
    if (!(p instanceof Player) || !p.hasTag(JOBS.fisher.t)) return;

    const it = ev.itemStack ?? ev.item;
    const fishes = ["minecraft:cod","minecraft:salmon",
                    "minecraft:tropical_fish","minecraft:pufferfish"];
    if (!fishes.includes(it.typeId)) return;

    am(p, JOBS.fisher.p, JOBS.fisher.n);
    addXP(p, 5);
});

/* 職業収入イベント ─ 畑 */
world.afterEvents.playerPlaceBlock.subscribe(ev=>{
  const p = ev.player;
  if (!p.hasTag(JOBS.farmer.t)) return;

  const id = ev.block.type.id;
  const crops = ["minecraft:wheat","minecraft:carrots","minecraft:potatoes","minecraft:beetroots"];
  if (!crops.includes(id)) return;

  am(p, JOBS.farmer.p, JOBS.farmer.n);
  addXP(p, 4);
});

world.afterEvents.playerBreakBlock.subscribe(ev=>{
  const id = ev.breakBlockPermutation ? ev.breakBlockPermutation.type.id
                                       : ev.brokenBlockPermutation.type.id;
  const p  = ev.player;
  if (p.hasTag(JOBS.farmer.t)){
       const crops = ["minecraft:wheat","minecraft:carrots","minecraft:potatoes","minecraft:beetroots"];
       if (crops.includes(id)){
          am(p, JOBS.farmer.p, JOBS.farmer.n);
          addXP(p, 4);
       }
  }
});



/* ダウンシステム */
world.afterEvents.entityDie.subscribe(ev=>{
  const p = ev.deadEntity;
  if (!(p instanceof Player)) return;

  /* プレイヤー死亡を検知したらドロップを消し、
     所持金・インベントリを一時保存しておく */
  const store = {
    x: p.location.x, y: p.location.y, z: p.location.z,
    money: gm(p),
    items: saveItems(p)
  };
  world.setDynamicProperty("death#" + p.id, JSON.stringify(store));
  ev.drops = [];            // ドロップキャンセル
  sm(p, 0);                 // 所持金ゼロ化
  system.run(()=> clearInv(p));
});

/* リスポーン後にメニューを出す */
world.afterEvents.playerSpawn.subscribe(ev=>{
  const p = ev.player;
  const raw = world.getDynamicProperty("death#" + p.id);
  if (!raw) return;                    // 通常スポーンなら無視
  const data = JSON.parse(raw);

  /* 1 tick 後に UI */
  system.run(()=>{
    new M().title("死亡しました")
      .body("救助を待ちますか？\n(所持品・所持金保持)")
      .button1("救助を待つ")
      .button2("諦めて復活(全ロスト)")
      .show(p).then(r=>{
        if(r.canceled) return;
        if(r.selection===0){           // 救助待ち
          // restoreItems(p,data.items);
          // sm(p,data.money);
          p.teleport({x:data.x, y:data.y, z:data.z});
          p.addTag("downed");
          // p.addEffect("slowness",999999,{amplifier:255});
          p.addEffect("mining_fatigue",999999,{amplifier:255});
          sendSOS(p);

          /* 所持品を保存して空にし、棒を渡す */
          // const saved = saveItems(p);                    // 配列で保存
          // world.setDynamicProperty("inv#" + p.id, JSON.stringify(saved));
          
          system.run(()=>{
            clearInv(p);                                       // 全消去
            const baton = new ItemStack("minecraft:stick",1);
            baton.nameTag = "諦める";
            p.getComponent("inventory").container.addItem(baton);
          });
        }
        // world.setDynamicProperty("death#"+p.id,undefined);
      });
  });
});

/* インベントリ操作ユーティリティ */
function clearInv(pl){
  const c = pl.getComponent("inventory").container;
  for (let i = 0; i < c.size; i++){
    c.setItem(i, null);  
  }
}
function dropAll(pl){
  sm(pl, 0);                       // お金 0
  clearInv(pl);                    // 全削除
}

function saveItems(pl){
  const c = pl.getComponent("inventory").container, arr = [];
  for (let i = 0; i < c.size; i++){
    const it = c.getItem(i);
    arr.push(it ? { id: it.typeId, amt: it.amount } : null);
  }
  return arr;
}

function restoreItems(pl, arr){
  const c = pl.getComponent("inventory").container;
  for (let i = 0; i < arr.length && i < c.size; i++){
    const v = arr[i];
    c.setItem(i, v ? new ItemStack(v.id, v.amt) : null);
  }
}




function askDownMenu(p){
  new M().title("致命傷を負った！")
    .body("救助を待ちますか？\n(所持品保持)")
    .button1("救助を待つ")
    .button2("諦めてリスポーン(アイテム・お金喪失)")
    .show(p).then(res=>{
      if(res.canceled) return;        // ESC ならそのまま待機
      if(res.selection===1){          // リスポーン選択
        dropAll(p);
        p.removeTag("downed");
        p.kill();                     // 通常死亡でリスポーン
      }
    });
}



function sendSOS(downed){
  const msg=`[救難] ${downed.nameTag} がダウン！ 座標: ${Math.floor(downed.location.x)}, ${Math.floor(downed.location.y)}, ${Math.floor(downed.location.z)}`;
  world.getPlayers().forEach(pl=>{
    if(pl.hasTag("job:paramedic")){
      pl.sendMessage(raw(`§c${msg}`));
    }
  });
}

/* 回復キット使用検知 */
const healEvent =
      (world.beforeEvents && world.beforeEvents.itemUse) ||
      (world.afterEvents  && world.afterEvents.itemUse)  ||
      (world.events       && world.events.itemUse);

if (healEvent) {
  healEvent.subscribe(ev => {
    const medic = ev.source;
    if (!(medic instanceof Player) ||
        !medic.hasTag("job:paramedic") ||
        !medic.isSneaking) return;

    const it = ev.itemStack;
    if (!(it && it.typeId === "minecraft:paper" && it.nameTag === "回復キット")) return;

    /* クリック対象 or 半径 3 m のダウン者 */
    let target = ev.blockHitEntity;
    if (!(target && target.hasTag && target.hasTag("downed"))) {
      target = world.getPlayers().find(p => p.hasTag("downed") && distance(p, medic) < 3);
    }
    if (!target) return;

    revive(target, medic);
    it.amount--;
  });
} else {
  console.warn("[JobEconomy] healEvent 取得失敗 – 回復キットが反応しません");
}


/* 距離計算ユーティリティ */
function distance(a, b){
  const dx=a.location.x-b.location.x,
        dy=a.location.y-b.location.y,
        dz=a.location.z-b.location.z;
  return Math.sqrt(dx*dx+dy*dy+dz*dz);
}



function revive(t,m){
  t.removeTag("downed");
  t.clearEffects();
  const h=t.getComponent("health");
  h.setCurrent(h.max);

   /* 保存しておいたアイテムと所持金を戻す */
  const raw = world.getDynamicProperty("death#" + t.id);
  if (raw){
    const data = JSON.parse(raw);
    restoreItems(t, data.items);
    sm(t, data.money);
    world.setDynamicProperty("death#" + t.id, undefined);
  }

  am(m, JOBS.paramedic.p, JOBS.paramedic.n);
  addXP(m, 8);                    // 救命士 XP +8 ★
  m.sendMessage(raw(`§a${t.nameTag} を救助し ${JOBS.paramedic.p}$ 獲得！`));
  t.sendMessage(raw("§a救助されました！"));
}

/* 諦める：ダウン者が右クリックで自決 */
const giveUpEvent =
      (world.beforeEvents && world.beforeEvents.itemUse) ||
      (world.afterEvents  && world.afterEvents.itemUse)  ||
      (world.events       && world.events.itemUse);

if (giveUpEvent) {
  giveUpEvent.subscribe(ev => {
    const p  = ev.source;
    if (!(p instanceof Player) || !p.hasTag("downed")) return;

    const it = ev.itemStack;
    if (!(it && it.typeId === "minecraft:stick" && it.nameTag === "諦める")) return;

    /* インベントリ書き換えは 1 tick 後に実行すると権限エラーにならない */
    system.run(() => {
      dropAll(p);            // お金 0・持ち物空
      p.removeTag("downed");
      world.setDynamicProperty("death#" + p.id, undefined);
      p.kill();              // 通常リスポーン
    });
  });
} else {
  console.warn("[JobEconomy] giveUpEvent 取得失敗 – 棒が反応しません");
}



/* ダウン者を完全停止 */
system.runInterval(() => {
  for (const pl of world.getPlayers()) {
    if (!pl.hasTag("downed")) continue;
    const loc = pl.location;
    pl.teleport({ x: loc.x, y: loc.y, z: loc.z });
  }
}, 1);

